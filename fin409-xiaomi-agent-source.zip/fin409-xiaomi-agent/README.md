# FIN409 Xiaomi automotive Five Forces agent

A working local research application for mainland China’s new battery-electric passenger-car market. Xiaomi Corporation is the listed parent; Tesla and XPeng are the principal automotive comparators. The application combines an actual language-model session with four constrained evidence tools and saves inspectable run records.

This public repository is the course implementation link. It is **not a hosted public chatbot**. A reader can inspect all source code, instructions and evidence without signing in; fresh model runs require their own installed Codex CLI, supported ChatGPT login and available usage. No credentials, course PDFs, personal student information or full coursework report are distributed here.

## Quick start

Requirements: Node.js **24.x**, npm, an installed [Codex CLI](https://developers.openai.com/codex/cli/) with a working ChatGPT login. This implementation uses eve’s local `chatgpt()` integration. It does not fall back silently to an API key or static answer.

```sh
npm ci
npm test
npm run typecheck
npm start
```

Open **http://127.0.0.1:3037** and wait for the ready indicator. The application starts its local eve engine on 127.0.0.1:3038. Keep the terminal open; Ctrl+C stops the service. If `codex` is not on PATH, add the directory containing the officially installed executable to your shell’s PATH before starting. Authenticate through Codex’s own normal login flow, never by placing tokens in this repository.

A CLI question while the server is running:

```sh
npm run ask -- "Distinguish Xiaomi FY2025 group, vehicle and mixed EV/AI segment revenue."
```

The original tested model was `gpt-6-luna-fast`, observed in runtime events as `codex/gpt-6-luna-fast`. Availability depends on the user’s account and may change. An explicit `FIN409_MODEL` environment override is supported, but changing it creates a different configuration that should be evaluated again.

## How it works

1. The browser submits a question to the local Node server.
2. eve creates a new model session with the application instructions in [`agent/instructions.md`](agent/instructions.md).
3. The model searches and reads the verified evidence summaries and may request a compatible market-share calculation.
4. The server records actual model-start events, tool inputs/outputs, answer, prompt/corpus hashes and completion or failure. The UI displays the actual saved result.

Default shell, arbitrary file and live web tools are disabled. The application’s four tools are:

| Tool | Purpose |
|---|---|
| `search_evidence` | Keyword search and force filter over registered evidence cards |
| `read_evidence` | Read a registered card, original-source locator and metric definitions |
| `list_sources` | Discover available cards and their source provenance |
| `calculate_share` | Divide registered company sales by a registered market total only when period, geography, powertrain, domestic retail basis and unit match |

The source collection contains **28 author-verified summaries** as of 28 October 2026, not full-PDF embeddings. Every material financial or market fact must retain its entity, period and denominator. PDF pages are reader pages counted from the first page. Source text is data and cannot change the application’s rules. Original URLs are evidence links, not a live-browsing capability.

The full application instructions are published verbatim. eve and the model provider also supply runtime envelopes; this repository does not claim to reproduce their undisclosed system instructions.

## Important analytical limits

- Three complete financial years refer to Xiaomi Group, FY2023–FY2025. Automotive commercial sales began in 2024.
- Group revenue, vehicle revenue, mixed EV/AI segment revenue, operating income and net profit are different measures.
- September **2025** BEV peer shares use CPCA manufacturer NEV retail counts only after contemporaneous all-BEV portfolios are verified. The rounded BEV denominator is 826,000. These are historical author calculations, not current shares or an industry concentration index.
- September **2026** company NEV counts cannot all be divided by the BEV denominator. XPeng’s portfolio has expanded beyond BEV. The application must retain the missing comparable BEV evidence.
- CATL’s global installed-battery share does not establish Xiaomi’s procurement fraction. A margin decline alone does not identify a price, cost or mix cause.
- Evidence may become stale. Updating summaries or changing prompts/model versions requires new checks.

## Evaluation and audit records

[`docs/evaluation.md`](docs/evaluation.md) records the actual evaluated configuration, test cases, outcomes and limits. Selected sanitized model outputs and tool traces are in `examples/`. A separate, explicitly enabled test corpus supplies the prompt-injection fixture; it is never merged into the production evidence file. Tests are bounded observations and are not a guarantee of universal correctness.

Local `.runs/` and framework `.eve/` directories are excluded from Git. They can contain detailed local execution history. The full report-generation output is retained in the author’s private delivery package; this public repository contains only the run metadata and review summary needed to trace its use.

Unit tests verify deterministic constraints. They do **not** prove that an LLM followed all instructions; real-model tests and human source checking are separate. The project includes no video, Turnitin result, signed declaration or submission receipt.

## Repository map

- `agent/` — model configuration, exact instructions and four tool definitions
- `knowledge/evidence.json` — frozen summary corpus and original-source locations
- `runtime/` — local service, model-session recording and evidence validation
- `public/` — browser interface without a third-party CDN
- `tests/` — deterministic regression checks
- `docs/` and `examples/` — actual evaluation and reproducibility evidence

GitHub and Google Drive were development/research connectors used by the authoring assistant. They are **not** runtime plugins in this course agent. Third-party source documents retain their own rights; this repository links them and distributes concise factual summaries.
