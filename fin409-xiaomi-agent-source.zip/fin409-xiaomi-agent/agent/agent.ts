import { defineAgent } from "eve";
import { chatgpt } from "eve/models/openai";

export default defineAgent({
  model: chatgpt(process.env.FIN409_MODEL || "gpt-6-luna-fast"),
  reasoning: "medium",
  defaultTools: false,
  limits: {
    sessionTimeoutMs: 600_000,
    sessionUsage: ({ window }) => window.inputTokens - window.cacheReadTokens > 120_000 || window.outputTokens > 12_000,
  },
});
