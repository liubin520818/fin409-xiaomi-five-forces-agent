import { defineTool } from "eve/tools";
import { z } from "zod";
import { withCorpus,searchEvidence } from "../../runtime/evidence.mjs";
export default defineTool({description:"Search the verified FIN409 evidence corpus. Returns exact IDs and source metadata; read the chosen evidence before citing.",inputSchema:z.object({query:z.string().min(1).max(500),force:z.enum(["rivalry","entrants","buyers","suppliers","substitutes","all"]).optional()}),execute:({query,force})=>withCorpus(searchEvidence,query,force)});
