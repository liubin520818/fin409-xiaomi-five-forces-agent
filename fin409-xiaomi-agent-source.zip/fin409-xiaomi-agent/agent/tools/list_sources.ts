import { defineTool } from "eve/tools";
import { z } from "zod";
import { withCorpus,listSources } from "../../runtime/evidence.mjs";
export default defineTool({description:"List available official source metadata and registered metric names; optionally limit to one force.",inputSchema:z.object({force:z.enum(["rivalry","entrants","buyers","suppliers","substitutes","all"]).optional()}),execute:({force})=>withCorpus(listSources,force)});
