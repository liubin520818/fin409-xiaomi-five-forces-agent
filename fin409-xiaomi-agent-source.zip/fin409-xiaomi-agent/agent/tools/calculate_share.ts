import { defineTool } from "eve/tools";
import { z } from "zod";
import { withCorpus,calculateShare } from "../../runtime/evidence.mjs";
const ref=z.object({record_id:z.string().min(1),metric_name:z.string().min(1)});
export default defineTool({description:"Calculate a vehicle retail market share using two registered evidence metrics. Rejects differing/unknown period, geography, powertrain, retail basis or unit; rejects raw numbers and cannot mix BEV with NEV.",inputSchema:z.object({numerator:ref,denominator:ref}),execute:({numerator,denominator})=>withCorpus(calculateShare,numerator,denominator)});
