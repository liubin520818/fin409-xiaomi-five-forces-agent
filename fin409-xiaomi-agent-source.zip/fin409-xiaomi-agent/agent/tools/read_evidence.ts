import { defineTool } from "eve/tools";
import { z } from "zod";
import { withCorpus,readEvidence } from "../../runtime/evidence.mjs";
export default defineTool({description:"Read a registered evidence record by exact ID, including full text, financial scope, actual PDF reader page and official URL. No file paths are accepted.",inputSchema:z.object({id:z.string().min(1).max(160)}),execute:({id})=>withCorpus(readEvidence,id)});
