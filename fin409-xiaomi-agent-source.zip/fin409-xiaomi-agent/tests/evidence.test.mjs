import test from 'node:test';
import assert from 'node:assert/strict';
import {calculateShare,searchEvidence,readEvidence} from '../runtime/evidence.mjs';
const base={period:'2025-09',geography:'China mainland',powertrain:'BEV',basis:'retail',unit:'vehicles'};
const rec=(id,name,value,overrides={})=>({id,title:'Source '+id,issuer:'Test issuer',source_url:'https://example.org/'+id,forces:['rivalry'],text:'BEV domestic retail Xiaomi Tesla XPeng',metrics:[{name,value,role:name==='market'?'market_total':'company_sales',...base,...overrides}]});
const corpus={schema_version:'1.0',corpus_version:'test',records:[rec('a','sales',71525),rec('b','market',826000)]};
const a={record_id:'a',metric_name:'sales'},b={record_id:'b',metric_name:'market'};
test('matching retail share calculated from registered inputs',()=>assert.equal(calculateShare(corpus,a,b).share_percent,71525/826000*100));
for(const key of ['period','geography','powertrain','basis','unit'])test('reject mismatched '+key,()=>{const c=structuredClone(corpus);c.records[1].metrics[0][key]='different';assert.equal(calculateShare(c,a,b).ok,false);});
test('reject missing scope',()=>{const c=structuredClone(corpus);delete c.records[1].metrics[0].period;assert.equal(calculateShare(c,a,b).ok,false);});
test('reject zero denominator',()=>{const c=structuredClone(corpus);c.records[1].metrics[0].value=0;assert.equal(calculateShare(c,a,b).ok,false);});
test('arbitrary path cannot read files',()=>assert.equal(readEvidence(corpus,'../../auth.json').error,'UNKNOWN_EVIDENCE_ID'));
test('search returns real source IDs and respects force',()=>{assert.equal(searchEvidence(corpus,'Xiaomi','rivalry').results.length,2);assert.equal(searchEvidence(corpus,'Xiaomi','suppliers').results.length,0);});

test('reject another company as market denominator',()=>{const c=structuredClone(corpus);c.records[1].metrics[0].role='company_sales';assert.equal(calculateShare(c,a,b).error,'INVALID_METRIC_ROLE');});
