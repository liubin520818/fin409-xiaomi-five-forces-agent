const args=process.argv.slice(2);const at=args.indexOf('--question');const fa=args.indexOf('--force');
const question=at>=0?args[at+1]:args.filter(x=>!x.startsWith('--')).join(' ');
if(!question){console.error('Usage: npm run ask -- --question "your question" [--force rivalry]');process.exit(1);}
const base=process.env.FIN409_BASE_URL||'http://127.0.0.1:3037';
const response=await fetch(base+'/api/run',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({question,force:fa>=0?args[fa+1]:'all'})});const receipt=await response.json();
if(!response.ok){console.error(JSON.stringify(receipt));process.exit(1);}
console.log('run_id='+receipt.run_id);
for(;;){await new Promise(r=>setTimeout(r,1000));const run=await(await fetch(base+'/api/runs/'+receipt.run_id)).json();if(['completed','failed'].includes(run.status)){console.log(JSON.stringify(run,null,2));process.exit(run.status==='completed'?0:1);}}
