import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {resolve,extname,sep} from 'node:path';
import {existsSync,readFileSync,mkdirSync,createWriteStream} from 'node:fs';
const root=resolve(fileURLToPath(new URL('..',import.meta.url)));process.chdir(root);
const port=Number(process.env.PORT||3037),enginePort=Number(process.env.EVE_PORT||3038);
process.env.EVE_BASE_URL ||= `http://127.0.0.1:${enginePort}`;
const {createRun,getRun,summaries,engineReady,isRunning,MODEL,PROMPT_VERSION}=await import('./runs.mjs');
const {loadCorpus}=await import('./evidence.mjs');
const runDir=process.env.FIN409_TEST_MODE==='1'?'.runs-test':'.runs';
mkdirSync(runDir,{recursive:true});
let engine;
if(process.env.EVE_EXTERNAL!=='1'){
 engine=spawn(process.execPath,[resolve(root,'node_modules/eve/bin/eve.js'),'dev','--no-ui','--no-default-extensions','--host','127.0.0.1','--port',String(enginePort)],{cwd:root,env:{...process.env,EVE_TELEMETRY_DISABLED:'1'},stdio:['ignore','pipe','pipe']});
 const log=createWriteStream(runDir+'/engine.log',{flags:'a'});engine.stdout.pipe(log);engine.stderr.pipe(log);engine.on('error',()=>console.error('eve could not start; inspect local .runs/engine.log.'));
}
function json(res,status,data){res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'});res.end(JSON.stringify(data));}
async function body(req){let s='';for await(const c of req){s+=c;if(s.length>20000)throw new Error('Request too large');}return JSON.parse(s||'{}');}
const server=createServer(async(req,res)=>{
 try{
  const host=req.headers.host??'';if(!/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host))return json(res,403,{error:'Local access only'});
  if(req.headers.origin&&!['http://'+host].includes(req.headers.origin))return json(res,403,{error:'Same-origin access required'});
  const url=new URL(req.url,'http://localhost');
  if(req.method==='GET'&&url.pathname==='/api/status'){
   let c;try{c=loadCorpus();}catch{};return json(res,200,{ready:!!c&&await engineReady(),engine:'eve',engine_version:'0.85.0',model:MODEL,prompt_version:PROMPT_VERSION,corpus_version:c?.corpus_version??null,evidence_count:c?.records.length??0,test_mode:c?.test_mode??false,running:isRunning()});
  }
  if(req.method==='POST'&&url.pathname==='/api/run'){
   if(!(await engineReady()))return json(res,503,{error:'Agent engine is still starting or unavailable.'});
   const r=createRun(await body(req));return json(res,202,{run_id:r.run_id,status:r.status});
  }
  if(req.method==='GET'&&url.pathname==='/api/runs')return json(res,200,{runs:summaries()});
  if(req.method==='GET'&&url.pathname.startsWith('/api/runs/')){
    const id=url.pathname.slice('/api/runs/'.length);if(!/^[a-f0-9-]{36}$/.test(id))return json(res,404,{error:'Unknown run'});
    const r=getRun(id);if(!r)return json(res,404,{error:'Unknown run'});
    const {system_prompt,application_prompt,...safe}=r;return json(res,200,safe);
  }
  if(req.method!=='GET')return json(res,405,{error:'Method not allowed'});
  const publicRoot=resolve(root,'public'),path=resolve(publicRoot,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
  if(!path.startsWith(publicRoot+sep)||!existsSync(path))return json(res,404,{error:'Not found'});
  res.writeHead(200,{'content-type':{'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json'}[extname(path)]||'application/octet-stream','x-content-type-options':'nosniff','cache-control':'no-store'});res.end(readFileSync(path));
 }catch(e){json(res,400,{error:e instanceof Error?e.message:'Invalid request'});}
});
server.listen(port,'127.0.0.1',()=>console.log(`FIN409 local app: http://127.0.0.1:${port}; engine starts separately and status is available at /api/status.`));
function stop(){engine?.kill('SIGTERM');server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),2000).unref();}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
