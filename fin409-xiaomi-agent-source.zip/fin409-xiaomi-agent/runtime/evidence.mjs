import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
export const FORCES = ['rivalry','entrants','buyers','suppliers','substitutes','all'];
export function loadCorpus() {
  const testMode = process.env.FIN409_TEST_MODE === '1';
  const raw = readFileSync(resolve(process.cwd(), testMode ? 'tests/fixtures/injection-corpus.json' : 'knowledge/evidence.json'), 'utf8');
  const corpus = JSON.parse(raw);
  if (corpus.schema_version !== '1.0' || !Array.isArray(corpus.records)) throw new Error('Unsupported evidence schema');
  const ids = new Set();
  for (const r of corpus.records) {
    if (!r.id || ids.has(r.id) || typeof r.text !== 'string' || !r.title || !r.issuer || !Array.isArray(r.forces)) throw new Error('Invalid or duplicate evidence record');
    if (!/^https:\/\//.test(r.source_url)) throw new Error('Evidence needs an HTTPS source URL');
    ids.add(r.id);
  }
  return { ...corpus, test_mode:testMode, sha256: createHash('sha256').update(raw).digest('hex') };
}
export function sourceMeta(r) { return { id:r.id,title:r.title,issuer:r.issuer,published_date:r.published_date??null,period:r.period??null,geography:r.geography??null,powertrain:r.powertrain??null,basis:r.basis??null,unit:r.unit??null,reader_page:r.reader_page??null,source_url:r.source_url,forces:r.forces,metrics:r.metrics??[] }; }
export function listSources(corpus, force) {
  return corpus.records.filter(r => !force || force === 'all' || r.forces.includes(force)).map(sourceMeta);
}
export function searchEvidence(corpus, query, force) {
  const words = query.toLowerCase().match(/[\p{L}\p{N}_-]+/gu) ?? [];
  const matches = corpus.records.filter(r=>!force||force==='all'||r.forces.includes(force)).map(r=>{
    const hay=[r.id,r.title,r.issuer,r.text,...r.forces].join(' ').toLowerCase();
    return {r,score:words.reduce((s,w)=>s+(hay.includes(w)?1:0),0)};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.r.id.localeCompare(b.r.id)).slice(0,8);
  return {query,force:force??'all',corpus_version:corpus.corpus_version,results:matches.map(({r,score})=>({...sourceMeta(r),score,excerpt:r.text.slice(0,1800)}))};
}
export function readEvidence(corpus,id) {
  const r=corpus.records.find(r=>r.id===id);
  if(!r) return {error:'UNKNOWN_EVIDENCE_ID',id};
  return {...sourceMeta(r),text:r.text,limitations:r.limitations??null};
}
function metric(corpus,ref) {
  const r=corpus.records.find(x=>x.id===ref.record_id);
  const m=(r?.metrics??[]).find(x=>x.name===ref.metric_name);
  if(!r||!m) throw new Error('Unknown registered metric: '+ref.record_id+'/'+ref.metric_name);
  return {record:r,metric:m};
}
export function calculateShare(corpus,numerator,denominator) {
  const a=metric(corpus,numerator),b=metric(corpus,denominator);
  if(a.metric.role!=='company_sales'||b.metric.role!=='market_total') return {ok:false,error:'INVALID_METRIC_ROLE',message:'A market share requires company_sales as numerator and market_total as denominator.'};
  const keys=['period','geography','powertrain','basis','unit'];
  const mismatches=keys.filter(k=>a.metric[k]==null||b.metric[k]==null||a.metric[k]!==b.metric[k]);
  if(mismatches.length) return {ok:false,error:'INCOMPATIBLE_METRICS',mismatches,numerator:a.metric,denominator:b.metric};
  if(a.metric.basis!=='retail'||a.metric.unit!=='vehicles'||!['BEV','NEV','PHEV','EREV','ICE'].includes(a.metric.powertrain)) return {ok:false,error:'NOT_A_RETAIL_VEHICLE_SHARE',message:'This tool requires matching vehicle retail metrics and an explicit powertrain.'};
  if(!Number.isFinite(a.metric.value)||!Number.isFinite(b.metric.value)||b.metric.value<=0||a.metric.value<0||a.metric.value>b.metric.value) return {ok:false,error:'INVALID_SHARE_VALUES'};
  return {ok:true,numerator_ref:numerator,denominator_ref:denominator,numerator:a.metric.value,denominator:b.metric.value,share_percent:a.metric.value/b.metric.value*100,share_percent_display:(a.metric.value/b.metric.value*100).toFixed(2)+'%',scope:Object.fromEntries(keys.map(k=>[k,a.metric[k]])),sources:[sourceMeta(a.record),sourceMeta(b.record)],note:'Approximate if either source value is rounded; retain the stated powertrain and retail scope.'};
}

export function withCorpus(fn,...args) {
 const c=loadCorpus(),result=fn(c,...args);
 return { ...(Array.isArray(result)?{sources:result}:result),corpus_version:c.corpus_version,corpus_sha256:c.sha256,test_mode:c.test_mode };
}
