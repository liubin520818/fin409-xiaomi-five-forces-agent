import { Client } from 'eve/client';
import { randomUUID,createHash } from 'node:crypto';
import { readFileSync,writeFileSync,mkdirSync,readdirSync,appendFileSync,renameSync } from 'node:fs';
import { resolve } from 'node:path';
import { loadCorpus,FORCES } from './evidence.mjs';
export const MODEL=process.env.FIN409_MODEL||'gpt-6-luna-fast';
export const PROMPT_VERSION='fin409-v1.1.0';
const dir=resolve(process.cwd(),process.env.FIN409_TEST_MODE==='1'?'.runs-test':'.runs');mkdirSync(dir,{recursive:true});
const runs=new Map();
for(const f of readdirSync(dir).filter(x=>/^[a-f0-9-]+\.json$/.test(x))){try{const r=JSON.parse(readFileSync(resolve(dir,f),'utf8'));if(['queued','running'].includes(r.status)){r.status='failed';r.error='Local server restarted before confirmed completion.';}runs.set(r.run_id,r);}catch{}}
const queue=[];let active=false;
const client=new Client({baseUrl:process.env.EVE_BASE_URL||'http://127.0.0.1:3038'});
function cleanError(e){return String(e?.message||e).replaceAll(process.cwd(),'[project]').replace(/\/Users\/[^\s/]+/g,'[home]').replace(/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g,'[redacted]');}
function save(r){const f=resolve(dir,r.run_id+'.json');writeFileSync(f+'.tmp',JSON.stringify(r,null,2)+'\n');renameSync(f+'.tmp',f);}
function audit(r,type,data){const event={at:new Date().toISOString(),type,data};appendFileSync(resolve(dir,r.run_id+'.jsonl'),JSON.stringify(event)+'\n');}
export async function engineReady(){try{await client.health();return true;}catch{return false;}}
export function summaries(){return [...runs.values()].sort((a,b)=>b.started_at.localeCompare(a.started_at)).map(({run_id,status,question,started_at,completed_at})=>({run_id,status,question,started_at,completed_at}));}
export function getRun(id){return runs.get(id);}
export function isRunning(){return active;}
export function createRun(input){
 if(typeof input?.question!=='string'||input.question.trim().length<3||input.question.length>8000)throw new Error('Question must contain 3–8000 characters.');
 if(input.force&&!FORCES.includes(input.force))throw new Error('Unsupported force.');
 if(queue.length>=8)throw new Error('Run queue is full.');
 const corpus=loadCorpus(),prompt=readFileSync(resolve(process.cwd(),'agent/instructions.md'),'utf8');
 const configFiles=['agent/agent.ts','agent/instructions.md','runtime/evidence.mjs','runtime/runs.mjs','package-lock.json',...['search_evidence','read_evidence','list_sources','calculate_share'].map(n=>'agent/tools/'+n+'.ts')];
 const config_hashes=Object.fromEntries(configFiles.map(f=>[f,createHash('sha256').update(readFileSync(resolve(process.cwd(),f))).digest('hex')]));
 const config_sha256=createHash('sha256').update(JSON.stringify(config_hashes)).digest('hex');
 const r={run_id:randomUUID(),status:'queued',question:input.question.trim(),force:input.force||'all',started_at:new Date().toISOString(),completed_at:null,answer:null,error:null,engine:'eve',engine_version:'0.85.0',model:MODEL,actual_models:[],prompt_version:PROMPT_VERSION,prompt_sha256:createHash('sha256').update(prompt).digest('hex'),application_prompt:prompt,prompt_scope:'Application instructions only; eve and the model provider may add runtime envelopes that are not represented as this application prompt.',config_sha256,config_hashes,test_mode:corpus.test_mode,corpus_version:corpus.corpus_version,corpus_sha256:corpus.sha256,tool_calls:[],sources:[],model_calls:[],session_id:null};
 runs.set(r.run_id,r);save(r);audit(r,'run.input',{question:r.question,force:r.force,model:r.model,prompt_version:r.prompt_version,prompt_sha256:r.prompt_sha256,config_sha256:r.config_sha256,test_mode:r.test_mode,corpus_version:r.corpus_version,corpus_sha256:r.corpus_sha256});queue.push(r);void drain();return r;
}
function recordEvent(r,e){
 const d=e.data??{},at=e.meta?.at??new Date().toISOString();
 if(e.type==='model.started'){
   const x={id:d.runId??null,model:d.modelId??null,attempt:d.attempt??null,at};r.model_calls.push(x);if(x.model&&!r.actual_models.includes(x.model))r.actual_models.push(x.model);audit(r,e.type,x);
 }
 if(e.type==='model.settled')audit(r,e.type,{id:d.runId??null,outcome:d.outcome,finishReason:d.finishReason,error:d.error?cleanError(d.error):null});
 if(e.type==='call.requested'){
   const x={id:d.callId,name:d.capability?.name??'unknown',input:d.input??{},output:null,status:'running',started_at:at,completed_at:null};r.tool_calls.push(x);audit(r,e.type,x);
 }
 if(e.type==='call.settled'){
   const x=r.tool_calls.find(c=>c.id===d.callId);
   if(x){x.output=d.output??(d.error?{error:cleanError(d.error)}:null);x.status=d.outcome||'completed';x.completed_at=at;
     if(x.name==='read_evidence'&&x.output?.id&&!x.output.error&&!r.sources.some(s=>s.id===x.output.id)){
       const v=x.output;r.sources.push({id:v.id,title:v.title,issuer:v.issuer,source_url:v.source_url,reader_page:v.reader_page??null});
     }
   }audit(r,e.type,{call_id:d.callId,outcome:d.outcome,output:d.output??null,error:d.error?cleanError(d.error):null});
   if(d.output?.corpus_sha256&&d.output.corpus_sha256!==r.corpus_sha256)throw new Error('Evidence corpus changed during this run. Start a new run to use the current version.');
 }
 // Deliberately do not retain reasoning, encrypted content, auth headers, or raw transport messages.
 save(r);
}
async function drain(){
 if(active)return;const r=queue.shift();if(!r)return;active=true;r.status='running';save(r);let session;const ac=new AbortController();const timer=setTimeout(()=>ac.abort(),Number(process.env.RUN_TIMEOUT_MS||600000));
 try{
   await client.health();
   const started=await client.sessions.create({message:`Requested force: ${r.force}. Question: ${r.question}`});session=started.session;r.session_id=started.delivery.sessionId;save(r);
   for await(const event of started.delivery.stream({signal:ac.signal}))recordEvent(r,event);
   const result=await started.delivery.result({signal:ac.signal});
   if(result.status!=='completed')throw new Error(result.error?.message||`Agent ended with status ${result.status}`);
   r.answer=result.reply||'';r.status='completed';
   if(!r.model_calls.length)throw new Error('No actual model.started event was recorded; run cannot be claimed verified.');
   if(!r.tool_calls.some(t=>['search_evidence','read_evidence','list_sources'].includes(t.name)))throw new Error('No evidence tool call was observed; run cannot be claimed evidence-grounded.');
   audit(r,'run.output',{answer:r.answer,actual_models:r.actual_models,tool_call_count:r.tool_calls.length,sources:r.sources});
 }catch(e){r.status='failed';r.error=cleanError(e);if(session)try{await session.cancel();}catch{}audit(r,'run.failed',{error:r.error});}
 finally{clearTimeout(timer);r.completed_at=new Date().toISOString();save(r);active=false;void drain();}
}
